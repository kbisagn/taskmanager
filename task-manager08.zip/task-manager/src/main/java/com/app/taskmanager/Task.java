package com.app.taskmanager;

public class Task {

}
